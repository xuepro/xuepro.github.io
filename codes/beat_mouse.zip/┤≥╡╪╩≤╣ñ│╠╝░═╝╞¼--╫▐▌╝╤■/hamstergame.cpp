#include "hamstergame.h"
#include "ui_hamstergame.h"
#include<QLabel>
#include<QTimer>
#include<QMessageBox>
#include<QMouseEvent>
#include<QTime>
#include<QTimerEvent>
#include<QCursor>
#include<QPixmap>
#include<QMouseEvent>
#include<QMessageBox>
#include<QAbstractButton>
#include "hamstergame.h"
#include <QApplication>

HamsterGame::HamsterGame(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::HamsterGame)
{
    ui->setupUi(this);
    score = 0;
    time = 0;
    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));//产生随机数
    this->setWindowOpacity(1);//设置透明度
    this->setWindowFlags(Qt::FramelessWindowHint);//去除边框
    this->setAttribute(Qt::WA_TranslucentBackground);//透明背景
    //this->ui->menuBar->hide();
    this->setStart(false);
    this->ui->mainToolBar->hide();
    this->ptimer = new QTimer;
    //this->p = new QTimer;
    connect(this->ptimer, SIGNAL(timeout()), this, SLOT(showMouse()));
    this->ui->stop->hide();
    this->setCursor(QCursor(QPixmap(":/icons/pictureUp.png")));
    ui->mouse1->setStyleSheet("QPushButton:pressed{border-image: url(:/icons/boom.png);}"
                              "QPushButton{border-image: url(:/icons/hello.png);}");
    ui->mouse2->setStyleSheet("QPushButton:pressed{border-image: url(:/icons/boom.png);}"
                              "QPushButton{border-image: url(:/icons/teeth.png);}");
    ui->mouse3->setStyleSheet("QPushButton:pressed{border-image: url(:/icons/boom.png);}"
                              "QPushButton{border-image: url(:/icons/family.png);}");
}

HamsterGame::~HamsterGame()
{
    delete ui;
}

void HamsterGame::mousePressEvent(QMouseEvent* event)
{
    this->setCursor(QCursor(QPixmap(":/icons/picturedown.png")));
    if (event->button() == Qt::LeftButton)
    {
        distance = event->globalPos()-frameGeometry().topLeft();
        event->accept();
    }
}

void HamsterGame::mouseReleaseEvent(QMouseEvent* event)
{
    this->setCursor(QCursor(QPixmap(":/icons/pictureUp.png")));
    if(event->buttons() & Qt::LeftButton)
    {
        move(event->globalPos()-distance);
        event->accept();
    }
}

void HamsterGame::on_mouse1_clicked()
{
    this->ui->mouse1->hide();
    if(this->isStart()){//修改
        score++;
        showScore();
    }
}

void HamsterGame::on_mouse2_clicked()
{
    this->ui->mouse2->hide();
    if(this->isStart()){
        score++;
        showScore();
    }
}

void HamsterGame::on_mouse3_clicked()
{
    this->ui->mouse3->hide();
    if(this->isStart()){
        score++;
        showScore();
    }
}

void HamsterGame::on_start_clicked()
{
    this->ui->start->hide();
    this->setStart(true);//设置flag
    this->ptimer->start(1000);
    this->ui->stop->show();

}

void HamsterGame::showMouse()
{
    time++;
    ui->label->setText("用时"+QString::number(time)+"s");
    ui->mouse1->move(qrand()%640+20, (qrand()%140)+160);
    ui->mouse2->move(qrand()%640+20, (qrand()%140)+160);
    ui->mouse3->move(qrand()%640+20, (qrand()%140)+160);//y坐标要在160~300,为了适应背景
    ui->mouse1->show();
    ui->mouse2->show();
    ui->mouse3->show();
    //ui->label->move(qrand()%640+20, (qrand()%140)+160);
}

void HamsterGame::showScore()
{
    ui->label_2->setText("命中"+QString::number(score)+"只");
    //this->setCursor(QCursor(QPixmap(":/icons/pictureUp")));
}

void HamsterGame::on_stop_clicked()
{
    this->setStart(false);//设置flag
    this->ptimer->stop();
    ui->label_2->setText("命中0只");
    ui->label->setText("用时0s");
    QMessageBox::information(NULL, "游戏结束", "太厉害了！击中了"+QString::number(this->score)+"只地鼠！", QMessageBox::Yes);
    this->ui->start->show();
    this->ui->stop->hide();
    this->score = 0;
    this->time = 0;
}

void HamsterGame::setStart(bool start){
    this->start = start;
}

bool HamsterGame::isStart(){
    return this->start;
}

void HamsterGame::on_line_clicked()
{
    this->showMinimized();
}

void HamsterGame::on_exit_clicked()
{
    this->close();
}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    HamsterGame w;
    w.show();

    return a.exec();
}

