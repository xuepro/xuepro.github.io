#ifndef HAMSTERGAME_H
#define HAMSTERGAME_H

#include <QMainWindow>
#include<QTimer>

namespace Ui {
class HamsterGame;
}

class HamsterGame : public QMainWindow
{
    Q_OBJECT

public:
    explicit HamsterGame(QWidget *parent = nullptr);
    ~HamsterGame();

private:
    Ui::HamsterGame *ui;
    int score, time;
    QTimer * ptimer;
    void showScore();
    QPoint distance;
    bool start; //解决游戏bug
protected:
    void mousePressEvent(QMouseEvent* event);
    void mouseReleaseEvent(QMouseEvent* event);
private slots:
    void on_mouse1_clicked();
    void on_mouse3_clicked();
    void on_mouse2_clicked();
    void on_start_clicked();
    void showMouse();
    void on_stop_clicked();
    bool isStart();
    void setStart(bool start);
    void on_line_clicked();
    void on_exit_clicked();
};

#endif // HAMSTERGAME_H
