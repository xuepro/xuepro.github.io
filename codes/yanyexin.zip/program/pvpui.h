#ifndef PVPUI_H
#define PVPUI_H

#include <QPainter>
#include <QWidget>
#include <QMouseEvent>
#include <QMessageBox>
#include <QMainWindow>
#include <QTimer>
#include <QTime>
#include <QPalette>
#include <QString>
#include "mainwindow.h"
namespace Ui {
class pvpui;
}

class pvpui : public QWidget
{
    Q_OBJECT

public:
    explicit pvpui(QWidget *parent = 0);
    ~pvpui();
    void paintEvent(QPaintEvent *);
    void mousePressEvent(QMouseEvent *e);
    int holder;
    int timeOut;
    QTimer *timer;
    bool WinJudge(int i,int j);
    int c[16][16];
    bool gameover;
    bool decide;
    bool huiqi;
    QPalette colorRed;
    QPalette colorBlack;
    QString zhizi;
    QPixmap baishengli;
    QPixmap heishengli;
signals:
    void sendsignal(bool);
private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void outoftime();

    void on_pushButton_4_clicked();

private:
    Ui::pvpui *ui;
};

#endif // PVPUI_H
