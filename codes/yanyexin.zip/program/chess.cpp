#include "chess.h"
int chess::chessRadius=20;
chess::chess()
{

}


