#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("五子棋游戏");
}
void MainWindow::paintEvent(QPaintEvent *)
{   QPainter painter(this);
    QPixmap background(":/new/prefix1/五子棋背景1.png");
    painter.drawPixmap(0,0,650,470,background);
}
MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::on_startpvp_click_clicked()
{
    pvpui *start=new pvpui();
    start->show();
    this->hide();
}

void MainWindow::on_startpve_click_clicked()
{
    pveui *start=new pveui();
    start->show();
    this->hide();
}

void MainWindow::on_pushButton_clicked()
{
    this->close();
}
