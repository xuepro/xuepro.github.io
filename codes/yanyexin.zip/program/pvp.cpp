//#include "pvp.h"

//pvp::pvp()
//{
//    setMinimumSize(1000,700);
//    setMaximumSize(1000,700);
//    setWindowTitle("五子棋游戏");
//    holder=1;
//    gameover=false;
//    for(int i=0;i<=14;i++)
//        for(int j=0;j<=14;j++)
//            c[i][j]=0;

//}
//void pvp::paintEvent(QPaintEvent *event){
//    QPainter p(this);
//    QColor color;
//    p.setPen(QPen(Qt::black,4,Qt::SolidLine));
//    p.drawLine(45,45,615,45);
//    p.drawLine(45,45,45,615);
//    p.drawLine(45,615,615,615);
//    p.drawLine(615,45,615,615);
//    for(int i=0;i<15;i++){
//        p.setPen(QPen(Qt::black,2,Qt::SolidLine));
//        p.drawLine(50,50+40*i,610,50+40*i);
//        p.drawLine(50+40*i,50,50+40*i,610);
//    }
//    p.drawEllipse(QPointF(170,170),3,3);
//    p.drawEllipse(QPointF(170,490),3,3);
//    p.drawEllipse(QPointF(490,170),3,3);
//    p.drawEllipse(QPointF(490,490),3,3);
//    p.drawEllipse(QPointF(330,330),3,3);
//    for(int i=0;i<=14;i++){
//        for(int j=0;j<=14;j++){
//            if(c[i][j]%2==1){
//                color=Qt::white;
//                p.setBrush(Qt::white);
//                p.setPen(QPen(QBrush(color),2));
//                p.drawEllipse(QPointF(50+40*i,50+40*j),16,16);
//            }
//            else if((c[i][j]%2!=1)&&c[i][j]!=0){
//                color=Qt::black;
//                p.setBrush(Qt::black);
//                p.setPen(QPen(QBrush(color),2));
//                p.drawEllipse(QPointF(50+40*i,50+40*j),16,16);
//            }
//        }
//    }
//}
//void pvp::mousePressEvent(QMouseEvent *e)
//{
//    if (e->button() != Qt::LeftButton) {
//        return;
//    }
////    click(e->pos());
//    for(int i=0;i<=14;i++){
//        if(abs(e->x()-(50+40*i))<=10){
//            for(int j=0;j<=14;j++){
//                if(abs(e->y()-(50+40*j))<=10){
//                    if(gameover){
//                            QMessageBox message(QMessageBox::NoIcon, "棋局已结束", "请选择清空棋盘！     ");
//                            message.exec();
//                            return;
//                        }
//                    else if(c[i][j]!=0){
//                        QMessageBox message(QMessageBox::NoIcon, "Error", "请正确落子！");
//                        message.exec();
//                        return;
//                    }
//                    c[i][j]=holder;
//                    repaint();
//                    if(WinJudge(i,j)){
//                        if(holder%2==1){
//                            QMessageBox message(QMessageBox::NoIcon, "比赛结束", "   白方胜！     ");
//                            message.exec();
//                            gameover=true;
//                        }
//                        else if(holder%2==0){
//                            QMessageBox message(QMessageBox::NoIcon, "比赛结束", "   黑方胜！     ");
//                            message.exec();
//                            gameover=true;
//                        }
//                    }
//                    holder+=1;
//                }
//            }
//        }
//    }
//}
//bool pvp::WinJudge(int i, int j){
//    int numshu=0,numheng=0,numxie1=0,numxie2=0;
//    for(int m=1;m<=14;m++){
//        if(((holder-c[i][j-m])%2==0)&&(c[i][j-m]!=0)){
//            numshu++;
//        }
//        else if(((holder-c[i][j-m])%2!=0)||(c[i][j-1]==0)) break;
//    }
//    for(int m=1;m<=14;m++){
//        if(((holder-c[i][j+m])%2==0)&&(c[i][j+m]!=0)){
//            numshu++;
//        }
//        else if(((holder-c[i][j+m])%2!=0)||(c[i][j+m]==0)) break;
//    }
//    if(numshu==4) return true;
//    for(int m=1;m<=14;m++){
//        if(((holder-c[i-m][j])%2==0)&&(c[i-m][j]!=0)){
//            numheng++;
//        }
//        else if(((holder-c[i-m][j])%2!=0)||(c[i-m][j]==0)) break;
//    }
//    for(int m=1;m<=14;m++){
//        if(((holder-c[i+m][j])%2==0)&&(c[i+m][j]!=0)){
//            numheng++;
//        }
//        else if(((holder-c[i+m][j])%2!=0)||(c[i+m][j]==0)) break;
//    }
//    if(numheng==4) return true;
//    for(int m=1;m<=14;m++){
//        if(((holder-c[i-m][j-m])%2==0)&&(c[i-m][j-m]!=0)){
//            numxie1++;
//        }
//        else if(((holder-c[i-m][j-m])%2!=0)||(c[i-m][j-m]==0)) break;
//    }
//    for(int m=1;m<=14;m++){
//        if(((holder-c[i+m][j+m])%2==0)&&(c[i+m][j+m]!=0)){
//            numxie1++;
//        }
//        else if(((holder-c[i+m][j+m])%2!=0)||(c[i+m][j+m]==0)) break;
//    }
//    if(numxie1==4) return true;
//    for(int m=1;m<=14;m++){
//        if(((holder-c[i+m][j+m])%2==0)&&(c[i+m][j+m]!=0)){
//            numxie2++;
//        }
//        else if(((holder-c[i+m][j+m])%2!=0)||(c[i+m][j+m]==0)) break;
//    }
//    for(int m=1;m<=14;m++){
//        if(((holder-c[i-m][j+m])%2==0)&&(c[i-m][j+m]!=0)){
//            numxie2++;
//        }
//        else if(((holder-c[i-m][j+m])%2!=0)||(c[i-m][j+m]==0)) break;
//    }
//    if(numxie2==4) return true;
//    else return false;
//}
