#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPalette>
#include "pvpui.h"
#include "pveui.h"
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    void paintEvent(QPaintEvent *);
    ~MainWindow();
public slots:
    void on_startpvp_click_clicked();
private slots:
    void on_startpve_click_clicked();

    void on_pushButton_clicked();

private :
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
