#include "pvpui.h"
#include "ui_pvpui.h"

pvpui::pvpui(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::pvpui)
{
    holder=0;
    gameover=false;
    huiqi=true;
    decide=true;
    zhizi=" ";
    baishengli.load(":/new/prefix1/白方胜.png");
    heishengli.load(":/new/prefix1/黑方胜.png");
    this->setAutoFillBackground(true);
    QPalette palette = this->palette();
    palette.setBrush(QPalette::Window,QBrush(QPixmap(":/new/prefix1/背景1.png")));
    this->setPalette(palette);
    colorRed.setColor(QPalette::WindowText,QColor(255,0,0));
    colorBlack.setColor(QPalette::WindowText,QColor(0,0,0));
    timeOut=30;
    ui->setupUi(this);
    ui->label_2->setText(zhizi);
    this->ui->lcdNumber->setPalette(colorBlack);
    this->ui->lcdNumber->display(QString::number(timeOut));
    this->timer=new QTimer;
    connect(this->timer,SIGNAL(timeout()),this,SLOT(outoftime()));
    setMinimumSize(1000,700);
    setMaximumSize(1000,700);
    setWindowTitle("玩家对战");
    for(int i=0;i<=15;i++)
        for(int j=0;j<=15;j++)
            c[i][j]=0;
}

pvpui::~pvpui()
{
    delete ui;
}
void pvpui::paintEvent(QPaintEvent *){
    QPainter p(this);
    QColor color;

    p.setPen(QPen(Qt::black,4,Qt::SolidLine));
    p.drawLine(45,45,615,45);
    p.drawLine(45,45,45,615);
    p.drawLine(45,615,615,615);
    p.drawLine(615,45,615,615);
    for(int i=0;i<15;i++){
        p.setPen(QPen(Qt::black,2,Qt::SolidLine));
        p.drawLine(50,50+40*i,610,50+40*i);
        p.drawLine(50+40*i,50,50+40*i,610);
    }
    p.drawEllipse(QPointF(170,170),3,3);
    p.drawEllipse(QPointF(170,490),3,3);
    p.drawEllipse(QPointF(490,170),3,3);
    p.drawEllipse(QPointF(490,490),3,3);
    p.drawEllipse(QPointF(330,330),3,3);
    for(int i=0;i<=14;i++){
        for(int j=0;j<=14;j++){
            if(c[i][j]%2==1){
                color=Qt::black;
                p.setBrush(Qt::white);
                p.setPen(QPen(QBrush(color),2));
                p.drawEllipse(QPointF(50+40*i,50+40*j),16,16);
            }
            else if((c[i][j]%2!=1)&&c[i][j]!=0){
                color=Qt::black;
                p.setBrush(Qt::black);
                p.setPen(QPen(QBrush(color),2));
                p.drawEllipse(QPointF(50+40*i,50+40*j),16,16);
            }
        }
    }
}
void pvpui::mousePressEvent(QMouseEvent *e)
{
    if (e->button() != Qt::LeftButton) {
        return;
    }
    if(gameover) this->ui->label_4->clear();
    for(int i=0;i<=14;i++){
        if(abs(e->x()-(50+40*i))<=10){
            for(int j=0;j<=14;j++){
                if(abs(e->y()-(50+40*j))<=10){
                    if(holder==0){
                        QMessageBox message(QMessageBox::NoIcon, "Error", "请先掷骰子定先！     ");
                        message.exec();
                        return;
                    }
                    if(gameover){
                            QMessageBox message(QMessageBox::NoIcon, "棋局已结束", "请选择重新开局！     ");
                            message.exec();
                            return;
                        }
                    else if(c[i][j]!=0){
                        QMessageBox message(QMessageBox::NoIcon, "Error", "请正确落子！     ");
                        message.exec();
                        return;
                    }
                    c[i][j]=holder;
                    timeOut=31;
                    update();
                    this->ui->lcdNumber->setPalette(colorBlack);
                    if(WinJudge(i,j)){
                        if(holder%2==1){
                            timer->stop();
                            this->ui->label_4->setScaledContents(true);
                            this->ui->label_4->setPixmap(baishengli);
                            huiqi=false;
                            zhizi=" ";
                            this->ui->label_2->setText(zhizi);
                            gameover=true;break;
                        }
                        else if(holder%2==0){
                            timer->stop();
                            this->ui->label_4->setScaledContents(true);
                            this->ui->label_4->setPixmap(heishengli);
                            huiqi=false;
                            zhizi=" ";
                            this->ui->label_2->setText(zhizi);
                            gameover=true;break;
                        }
                    }
                    holder+=1;
                    if(holder%2==1) zhizi="白方执子";
                    else if(holder%2==0) zhizi="黑方执子";
                    ui->label_2->setText(zhizi);
                }
            }
        }
    }
}
bool pvpui::WinJudge(int i, int j){
    int numshu=0,numheng=0,numxie1=0,numxie2=0;
    for(int m=1;m<=14;m++){
        if(((holder-c[i][j-m])%2==0)&&(c[i][j-m]!=0)){
            numshu++;
        }
        else if(((holder-c[i][j-m])%2!=0)||(c[i][j-1]==0)) break;
    }
    for(int m=1;m<=14;m++){
        if(((holder-c[i][j+m])%2==0)&&(c[i][j+m]!=0)){
            numshu++;
        }
        else if(((holder-c[i][j+m])%2!=0)||(c[i][j+m]==0)) break;
    }
    if(numshu==4) return true;
    for(int m=1;m<=14;m++){
        if(((holder-c[i-m][j])%2==0)&&(c[i-m][j]!=0)){
            numheng++;
        }
        else if(((holder-c[i-m][j])%2!=0)||(c[i-m][j]==0)) break;
    }
    for(int m=1;m<=14;m++){
        if(((holder-c[i+m][j])%2==0)&&(c[i+m][j]!=0)){
            numheng++;
        }
        else if(((holder-c[i+m][j])%2!=0)||(c[i+m][j]==0)) break;
    }
    if(numheng==4) return true;
    for(int m=1;m<=14;m++){
        if(((holder-c[i-m][j-m])%2==0)&&(c[i-m][j-m]!=0)){
            numxie1++;
        }
        else if(((holder-c[i-m][j-m])%2!=0)||(c[i-m][j-m]==0)) break;
    }
    for(int m=1;m<=14;m++){
        if(((holder-c[i+m][j+m])%2==0)&&(c[i+m][j+m]!=0)){
            numxie1++;
        }
        else if(((holder-c[i+m][j+m])%2!=0)||(c[i+m][j+m]==0)) break;
    }
    if(numxie1==4) return true;
    for(int m=1;m<=14;m++){
        if(((holder-c[i+m][j-m])%2==0)&&(c[i+m][j-m]!=0)){
            numxie2++;
        }
        else if(((holder-c[i+m][j-m])%2!=0)||(c[i+m][j-m]==0)) break;
    }
    for(int m=1;m<=14;m++){
        if(((holder-c[i-m][j+m])%2==0)&&(c[i-m][j+m]!=0)){
            numxie2++;
        }
        else if(((holder-c[i-m][j+m])%2!=0)||(c[i-m][j+m]==0)) break;
    }
    if(numxie2==4) return true;
    else return false;
}

void pvpui::on_pushButton_clicked()
{
    for(int i=0;i<=14;i++)
        for(int j=0;j<=14;j++)
            c[i][j]=0;
    update();
    gameover=false;
    decide=true;
    huiqi=true;
    zhizi=" ";
    holder=0;
    timer->stop();
    timeOut=30;
    this->ui->lcdNumber->display(QString::number(timeOut));
    ui->label_2->setText(zhizi);
}

void pvpui::on_pushButton_2_clicked()
{
    if(!decide) return;
    int min=1,max=10;
    Q_ASSERT(min < max);
    static bool seedStatus;
    if (!seedStatus)
    {
        qsrand(QTime(0, 0, 0).secsTo(QTime::currentTime()));
        seedStatus = true;
    }
    int nRandom = qrand() % (max - min);
    nRandom = min + nRandom;
    if(nRandom%2==1){
        QMessageBox message(QMessageBox::NoIcon, " ", "   白子先手！     ");
        message.exec();
        decide=false;
        holder=1;
        timer->start(1000);
        zhizi="白方执子";
        ui->label_2->setText(zhizi);
    }
    if(nRandom%2==0){
        QMessageBox message(QMessageBox::NoIcon, " ", "   黑子先手！     ");
        message.exec();
        decide=false;
        holder=2;
        timer->start(1000);
        zhizi="黑方执子";
        ui->label_2->setText(zhizi);
    }
}
void pvpui::outoftime(){
    if(timeOut<=10&&timeOut>0) this->ui->lcdNumber->setPalette(colorRed);
    else if(timeOut<=0){
        if(holder%2==1){
            QMessageBox message(QMessageBox::NoIcon, " ", "   白方弃子！     ");
            message.exec();
            holder++;
            zhizi="黑方执子";
            this->ui->label_2->setText(zhizi);
            this->ui->lcdNumber->setPalette(colorBlack);
            timeOut=31;
        }
        else if(holder%2==0){
            QMessageBox message(QMessageBox::NoIcon, " ", "   黑方弃子！     ");
            message.exec();
            holder++;
            zhizi="白方执子";
            this->ui->label_2->setText(zhizi);
            this->ui->lcdNumber->setPalette(colorBlack);
            timeOut=31;
        }
    }
    this->ui->lcdNumber->display(--timeOut);
}

void pvpui::on_pushButton_3_clicked()
{
    timer->stop();
    timeOut=30;
    MainWindow *back=new MainWindow();
    back->show();
    this->hide();
}

void pvpui::on_pushButton_4_clicked()
{
    if(!huiqi) return;
    else if(holder<=1) return;
    for(int i=0;i<=14;i++)
        for(int j=0;j<=14;j++)
            if(c[i][j]==(holder-1)){
                c[i][j]=0;
                break;
            }
    holder--;
    timeOut=31;
    if(holder%2==1) zhizi="白方执子";
    else if(holder%2==0) zhizi="黑方执子";
    ui->label_2->setText(zhizi);
    update();
}
