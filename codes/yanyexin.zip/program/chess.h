#ifndef CHESS_H
#define CHESS_H

class chess
{
public:
    chess();
    static int chessRadius;
};

#endif // CHESS_H
