//#ifndef MENU_H
//#define MENU_H
//#include <QPainter>
//#include <QWidget>
//#include <QMouseEvent>
//#include <QMessageBox>
//#include <QMainWindow>
//class pvp:public QMainWindow
//{
//    Q_OBJECT
//public:
//    pvp();
//    //    void clear();
//        void paintEvent(QPaintEvent *event);
//        void mousePressEvent(QMouseEvent *e);
//        int holder;
//        bool WinJudge(int i,int j);
//        int c[15][15];
//        bool gameover;
//};

//#endif // MENU_H
