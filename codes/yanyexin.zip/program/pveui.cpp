#include "pveui.h"
#include "ui_pveui.h"

# define SPA 0
# define MAN 1
# define COM 2

pveui::pveui(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::pveui)
{
    holder=1;
    gameover=false;
    player=false;
    huiqi=false;
    restart=true;
    huicol=0,huirow=0;
    playerhuicol=0,playerhuirow=0;
    zhizi="玩家执子";
    wanshengli.load(":/new/prefix1/玩家胜.png");
    dianshengli.load(":/new/prefix1/电脑胜.png");
    this->setAutoFillBackground(true);
    QPalette palette = this->palette();
    palette.setBrush(QPalette::Window,QBrush(QPixmap(":/new/prefix1/背景1.png")));
    this->setPalette(palette);
    ui->setupUi(this);
    ui->label_2->setText(zhizi);
    setMinimumSize(1000,700);
    setMaximumSize(1000,700);
    setWindowTitle("人机对战");
    for(int i=0;i<16;i++)
        for(int j=0;j<16;j++)
            c[i][j]=0;
}
pveui::~pveui()
{
    delete ui;
}
void pveui::paintEvent(QPaintEvent *){
    QPainter p(this);
    QColor color;
    p.setPen(QPen(Qt::black,4,Qt::SolidLine));
    p.drawLine(45,45,615,45);
    p.drawLine(45,45,45,615);
    p.drawLine(45,615,615,615);
    p.drawLine(615,45,615,615);
    for(int i=1;i<16;i++){
        p.setPen(QPen(Qt::black,2,Qt::SolidLine));
        p.drawLine(50,10+40*i,610,10+40*i);
        p.drawLine(10+40*i,50,10+40*i,610);
    }
    p.drawEllipse(QPointF(170,170),3,3);
    p.drawEllipse(QPointF(170,490),3,3);
    p.drawEllipse(QPointF(490,170),3,3);
    p.drawEllipse(QPointF(490,490),3,3);
    p.drawEllipse(QPointF(330,330),3,3);
    for(int i=1;i<16;i++){
        for(int j=1;j<16;j++){
            if(c[i][j]==1){
                color=Qt::black;
                p.setBrush(Qt::white);
                p.setPen(QPen(QBrush(color),2));
                p.drawEllipse(QPointF(10+40*i,10+40*j),16,16);
            }
            else if(c[i][j]==2){
                color=Qt::black;
                p.setBrush(Qt::black);
                p.setPen(QPen(QBrush(color),2));
                p.drawEllipse(QPointF(10+40*i,10+40*j),16,16);
            }
        }
    }
}
void pveui::mousePressEvent(QMouseEvent *e)
{
    if (e->button() != Qt::LeftButton) {
        return;
    }
    if(gameover) this->ui->label_4->clear();
    if(e->x()<40||e->x()>620||e->y()<40||e->y()>620){
        return;
    }
    if(holder==2) return;
    for(int i=1;i<=15;i++){
        if(abs(e->x()-(10+40*i))<=10){
            for(int j=1;j<=15;j++){
                if(abs(e->y()-(10+40*j))<=10){
                    if(gameover){
                            QMessageBox message(QMessageBox::NoIcon, "棋局已结束", "请选择重新开局！     ");
                            message.exec();
                            return;
                        }
                    else if(c[i][j]!=0){
                        QMessageBox message(QMessageBox::NoIcon, "Error", "请正确落子！     ");
                        message.exec();
                        return;
                    }
                    c[i][j]=holder;
                    playerhuirow=i,playerhuicol=j;
                    player=true;
                    huiqi=true;
                    update();
                    if(WinJudge(i,j)){
                        if(holder%2==1){
                            this->ui->label_4->setScaledContents(true);
                            this->ui->label_4->setPixmap(wanshengli);
                            zhizi="  ";
                            this->ui->label_2->setText(zhizi);
                            update();
                            holder=1;
                            gameover=true;
                            huiqi=false;break;
                        }
                        else if(holder%2==0){
                            this->ui->label_4->setScaledContents(true);
                            this->ui->label_4->setPixmap(dianshengli);
                            zhizi="  ";
                            this->ui->label_2->setText(zhizi);
                            update();
                            holder=1;
                            gameover=true;
                            huiqi=false;break;
                        }
                    }
                    holder=2;
                    zhizi="电脑执子";
                    this->ui->label_2->setText(zhizi);
                }
            }
        }
    }
    if((!gameover)&&player){
        huiqi=false;
        restart=false;
        Sleep(800);
        int row,col;
        AI(&col,&row);
        huirow=row+1,huicol=col+1;
        c[row+1][col+1]=holder;
        update();
        if(WinJudge(row+1,col+1)){
            if(holder==1){
                this->ui->label_4->setScaledContents(true);
                this->ui->label_4->setPixmap(wanshengli);
                zhizi=" ";
                ui->label_2->setText(zhizi);
                holder=1;
                gameover=true;
                huiqi=false;
                restart=true;
                return;
            }
            else if(holder==2){
                this->ui->label_4->setScaledContents(true);
                this->ui->label_4->setPixmap(dianshengli);
                zhizi=" ";
                ui->label_2->setText(zhizi);
                holder=1;
                gameover=true;
                huiqi=false;
                restart=true;
                return;
            }
        }
        zhizi="玩家执子";
        this->ui->label_2->setText(zhizi);
        holder=1;
        player=false;
        restart=true;
        huiqi=true;
    }
}
void pveui::AI(int *p, int *q){
    int i, j, value, max = 0, bestRow, bestCol;
    for (j = 0; j<15; j++)
        for (i = 0; i<15; i++)
            if (c[j+1][i+1] == 0) {
                value = positionValue(i, j);
                if (value >= max) { bestRow = i; bestCol = j; max = value; }
            }
    *p = bestRow; *q = bestCol;
}
int pveui::positionValue(int row, int col)
{
    int n = 1, k = 0, k1, k2, K1, K2, X1, Y1, Z1, X2, Y2, Z2, temp;
    int a[2][4][4] = { 40,400,3000,10000,6,10,600,10000,20,120,200,0,6,10,500,0,30,300,2500,5000,2,8,300,10000,26,160,0,0,4,20,300,0 };
    while (n != 5) {
        k1 = chessType(n, row, col); n += 4;
        k2 = chessType(n, row, col); n -= 3;
        if (k1>k2) {
            temp = k1;
            k1 = k2;
            k2 = temp;
        }
        K1 = k1; K2 = k2;
        Z1 = k1 % 10; Z2 = k2 % 10; k1 /= 10; k2 /= 10; Y1 = k1 % 10; Y2 = k2 % 10; k1 /= 10; k2 /= 10; X1 = k1 % 10; X2 = k2 % 10;
        if (K1 == -1) {
            if (K2<0) {
                k += 0;
                continue;
            }
            else k += a[X2][Y2][Z2] + 5;
            continue;
        };
        if (K1 == -2) {
            if (K2<0) {
                k += 0;
                continue;
            }
            else k += a[X2][Y2][Z2] / 2;
            continue;
        };
        if (K1 == -3) {
            if (K2<0) {
                k += 0;
                continue;
            }
            else k += a[X2][Y2][Z2] / 3;
            continue;
        };
        if (((K1>-1 && K1<4) && ((K2>-1 && K2<4) || (K2>9 && K2<14))) || ((K1>99 && K1<104) && ((K2>99 && K2<104) || (K2>109 && K2<114)))) {
            if (Z1 + Z2 >= 2) {
                k += a[X2][Y2][3];
                continue;
            }
            else {
                k += a[X2][Y2][Z1 + Z2 + 1];
                continue;
            }
        }
        if (((K1>9 && K1<14) && (K2>9 && K2<14)) || ((K1>109 && K1<114) && (K2>109 && K2<114))) {
            if (Z1 + Z2 >= 2) {
                k += 10000;
                continue;
            }
            else {
                k += 0;
                continue;
            }
        }
        if (((K1>-1 && K1<4) && ((K2>99 && K2<104) || (K2>109 && K2<114))) || ((K1>9 && K1<14) && ((K2>99 && K2<104) || (K2>109 && K2<114)))) {
            if (Z1 == 3 || Z2 == 3) {
                k += 10000;
                continue;
            }
            else {
                k += a[X2][Y2][Z2] + a[X1][Y1][Z1] / 4;
                continue;
            }
        }
        else {
            k += a[X1][Y1][Z1] + a[X2][Y2][Z2];
            continue;
        }
    }
    return k;
}
int pveui::chessType(int n, int p, int q)
{
    int k, m = 0;
    goStep(n, &p, &q);
    if (p<0 || p>14 || q<0 || q>14) k = -2;
    switch (c[q+1][p+1]) {
    case COM: {
        m++; goStep(n, &p, &q);
        if (p<0 || p>14 || q<0 || q>14) {
            k = m + 9;
            return k;
        }
        while (c[q+1][p+1] == COM) { m++;
            goStep(n, &p, &q);
            if (p<0 || p>14 || q<0 || q>14) {
                k = m + 9;
                return k;
            }
        }
        if (c[q+1][p+1] == SPA) k = m - 1;
        else k = m + 9;
    }break;
    case MAN: {
        m++; goStep(n, &p, &q);
        if (p<0 || p>14 || q<0 || q>14) {
            k = m + 109;
            return k;
        }
        while (c[q+1][p+1] == MAN) {
            m++; goStep(n, &p, &q);
            if (p<0 || p>14 || q<0 || q>14) {
                k = m + 109;
                return k;
            }
        }
        if (c[q+1][p+1] == SPA) k = m + 99;
        else k = m + 109;
    }break;
    case SPA: {
        goStep(n, &p, &q);
        if (p<0 || p>14 || q<0 || q>14) {
            k = -3;
            return k;
        }
        switch (c[q+1][p+1]) {
        case COM: {
            m++;
            goStep(n, &p, &q);
            if (p<0 || p>14 || q<0 || q>14) {
                k = m + 29;
                return k;
            }
            while (c[q+1][p+1] == COM) {
                m++;
                goStep(n, &p, &q);
                if (p<0 || p>14 || q<0 || q>14) {
                    k = m + 29;
                    return k;
                }
            }
            if (c[q+1][p+1] == SPA) k = m + 19;
            else k = m + 29;
        }break;
        case MAN: {
            m++; goStep(n, &p, &q);
            if (p<0 || p>14 || q<0 || q>14) { k = m + 129; return k; }
            while (c[q+1][p+1] == MAN) {
                m++;
                goStep(n, &p, &q);
                if (p<0 || p>14 || q<0 || q>14) {
                    k = m + 129;
                    return k;
                }
            }
            if (c[q+1][p+1] == SPA) k = m + 119;
            else k = m + 129;
        }break;
        case SPA: k = -1; break;
        }
    }break;
    }
    return k;
}
void pveui::goStep(int n, int *i, int *j)
{
    switch (n) {
        case 1: *i += 1; break;
        case 2: *i += 1; *j += 1; break;
        case 3: *j += 1; break;
        case 4: *i -= 1; *j += 1; break;
        case 5: *i -= 1; break;
        case 6: *i -= 1; *j -= 1; break;
        case 7: *j -= 1; break;
        case 8: *i += 1; *j -= 1; break;
        }
}
//bool pveui::WinJudge(int i, int j){
//    int numshu=0,numheng=0,numxie1=0,numxie2=0;
//    for(int m=1;m<=14;m++){
//        if(((holder-c[i][j-m])%2==0)&&(c[i][j-m]!=0)){
//            numshu++;
//        }
//        else if(((holder-c[i][j-m])%2!=0)||(c[i][j-1]==0)) break;
//    }
//    for(int m=1;m<=14;m++){
//        if((c[i][j+m]!=0)&&((holder-c[i][j+m])%2==0)){
//            numshu++;
//        }
//        else if(((holder-c[i][j+m])%2!=0)||(c[i][j+m]==0)) break;
//    }
//    if(numshu>=4) return true;
//    for(int m=1;m<=14;m++){
//        if((c[i-m][j]!=0)&&((holder-c[i-m][j])%2==0)){
//            numheng++;
//        }
//        else if(((holder-c[i-m][j])%2!=0)||(c[i-m][j]==0)) break;
//    }
//    for(int m=1;m<=14;m++){
//        if((c[i+m][j]!=0)&&((holder-c[i+m][j])%2==0)){
//            numheng++;
//        }
//        else if(((holder-c[i+m][j])%2!=0)||(c[i+m][j]==0)) break;
//    }
//    if(numheng>=4) return true;
//    for(int m=1;m<=14;m++){
//        if((c[i-m][j-m]!=0)&&((holder-c[i-m][j-m])%2==0)){
//            numxie1++;
//        }
//        else if(((holder-c[i-m][j-m])%2!=0)||(c[i-m][j-m]==0)) break;
//    }
//    for(int m=1;m<=14;m++){
//        if((c[i+m][j+m]!=0)&&((holder-c[i+m][j+m])%2==0)){
//            numxie1++;
//        }
//        else if(((holder-c[i+m][j+m])%2!=0)||(c[i+m][j+m]==0)) break;
//    }
//    if(numxie1>=4) return true;
//    for(int m=1;m<=14;m++){
//        if((c[i+m][j-m]!=0)&&((holder-c[i+m][j-m])%2==0)){
//            numxie2++;
//        }
//        else if(((holder-c[i+m][j-m])%2!=0)||(c[i+m][j-m]==0)) break;
//    }
//    for(int m=1;m<=14;m++){
//        if((c[i-m][j+m]!=0)&&((holder-c[i-m][j+m])%2==0)){
//            numxie2++;
//        }
//        else if(((holder-c[i-m][j+m])%2!=0)||(c[i-m][j+m]==0)) break;
//    }
//    if(numxie2>=4) return true;
//    else return false;
//}
bool pveui::WinJudge(int row, int col)
{
    int dx[8]={0,1,1,1,0,-1,-1,-1};
    int dy[8]={1,1,0,-1,-1,-1,0,1};
    if(row>15||col>15) return false;
    int currentSide=c[row][col];

    int cnt,r,b,i;
    for(i=0;i<4;i++){
        int dir=i;
        cnt=0;
        r=row;
        b=col;
        while(c[r][b]==currentSide){
            cnt++;
            r+=dy[dir];
            b+=dx[dir];
        }
        dir+=4;
        r=row;
        b=col;
        while(c[r][b]==currentSide){
            cnt++;
            r+=dy[dir];
            b+=dx[dir];
        }
        if(cnt>5){

            return true;
        }
    }
    return false;
}

void pveui::on_pushButton_clicked()
{
    if(restart){
        for(int i=0;i<16;i++)
            for(int j=0;j<16;j++)
                c[i][j]=0;
        zhizi="玩家执子";
        this->ui->label_2->setText(zhizi);
        update();
        holder=1;
        gameover=false;
    }
}

void pveui::on_pushButton_3_clicked()
{
    MainWindow *back=new MainWindow();
    back->show();
    this->hide();
}

void pveui::on_pushButton_4_clicked()
{
    if(!huiqi) return;
    c[playerhuirow][playerhuicol]=0;
    c[huirow][huicol]=0;
    update();
    huiqi=false;
}
void pveui::Sleep(unsigned int msec){
    QTime reachtime=QTime::currentTime().addMSecs(msec);
    while(QTime::currentTime()<reachtime)
        QCoreApplication::processEvents(QEventLoop::AllEvents,100);
}
