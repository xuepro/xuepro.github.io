#ifndef PVEUI_H
#define PVEUI_H
#include <QApplication>
#include <QPainter>
#include <QWidget>
#include <QMouseEvent>
#include <QMessageBox>
#include <QMainWindow>
#include <QTime>
#include <QPalette>
#include <QString>
#include "mainwindow.h"

namespace Ui {
class pveui;
}

class pveui : public QWidget
{
    Q_OBJECT

public:
    explicit pveui(QWidget *parent = 0);
    ~pveui();
    void paintEvent(QPaintEvent *);
    void mousePressEvent(QMouseEvent *e);
    void computerPlaceChess();
    void AI(int *p,int *q);
    int positionValue(int row,int col);
    int chessType(int n, int p, int q);
    void goStep(int n, int *i, int *j);
    void Sleep(unsigned int msec);
    int c[16][16];
    int holder;
    int huirow,huicol;
    int playerhuirow,playerhuicol;
    bool huiqi;
    bool gameover;
    bool WinJudge(int row, int col);
    bool player;
    bool restart;
    QString zhizi;
    QPixmap wanshengli;
    QPixmap dianshengli;
private slots:
    void on_pushButton_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::pveui *ui;
};

#endif // PVEUI_H
